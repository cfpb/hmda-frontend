# Installation
> `npm install --save @types/vinyl`

# Summary
This package contains type definitions for vinyl (https://github.com/gulpjs/vinyl).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vinyl.

### Additional Details
 * Last updated: Tue, 26 Sep 2023 10:06:28 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [vvakame](https://github.com/vvakame), and [Georgii Dolzhykov](https://github.com/thorn0).
